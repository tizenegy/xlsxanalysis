Save the .xslx you would like to analyse
in the same folder as the .exe
and wait for the result (.txt file).
Depending on the size of the .xlsx this may take
a few minutes.
After the analysis please remove the .xlsx so next time the right file will be used.